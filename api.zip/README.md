# Shop app with React and node server with mongodb
we create shop app with react redux core and node.js and mongodb
